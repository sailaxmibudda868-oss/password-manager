# Report Alignment

Use the project name: **Password Manager**

Actual implementation:
- Language: Python
- GUI: Tkinter
- Database: SQLite
- Encryption: AES-256-GCM
- Key derivation/authentication: PBKDF2-HMAC-SHA256
- Operations: Create, Read, Update, Delete
- Password generator: Python `secrets` module

Do not claim MySQL, Java, browser autofill, cloud synchronization, 2FA or biometric login unless those features are actually implemented.
