CREATE TABLE users (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    master_hash TEXT NOT NULL,
    salt TEXT NOT NULL
);

CREATE TABLE credentials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    website TEXT NOT NULL,
    username TEXT NOT NULL,
    password TEXT NOT NULL,
    notes TEXT DEFAULT ''
);
